class AppIcon{
     static const String image = "assets/Imgg/logo.png";
}