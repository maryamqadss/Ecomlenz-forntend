package com.ecomlenz.ecomlenz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
